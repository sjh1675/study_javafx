package hospital.controller.util;

public interface Changable {

	void loadView();
	
}
